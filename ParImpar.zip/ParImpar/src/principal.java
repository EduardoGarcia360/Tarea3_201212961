import java.util.Scanner;
public class principal {

	public static void main(String[] args) {
		Scanner num=new Scanner(System.in);
    	int num1;
    	System.out.println("ingrese un NUMERO para comprobar");
    	num1=num.nextInt();
		if(num1%2==1){
			System.out.println("es impar");
		}else{
			System.out.println("es par");
		}

	}

}
